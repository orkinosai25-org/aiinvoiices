import mongoose from "mongoose";

export const connectDB = async ()=>{
    await mongoose.connect('mongodb+srv://aiinvoicegenerator202604:VOBL3JddRy1YOexG@cluster0.xlfgiej.mongodb.net/PromptToInvoice')
    .then(()=> {console.log('DB CONNECTED')})
}